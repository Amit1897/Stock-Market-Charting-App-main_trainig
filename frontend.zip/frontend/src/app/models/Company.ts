export interface Company {
  id?: string;
  name?: string;
  code?: string;
  turnover?: string;
  ceo?: string;
  boardOfDirectors?: string;
  stockExchangeNames?: string;
  sectorName?: string;
  description?: string;
}
