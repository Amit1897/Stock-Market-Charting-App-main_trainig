export interface Comparison {
  name?: string;
  stockExchangeName?: string;
  fromPeriod?: string;
  toPeriod?: string;
  periodicity?: string;
}
